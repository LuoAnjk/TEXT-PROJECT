<template>
  <div class="app-container">
    <Layout>
      <template #left>
        <div class="aside">
          <SiteAside></SiteAside>
        </div>
      </template>
      <template #default>
        <RouterView />
        <!-- <router-view></router-view> -->
      </template>
    </Layout>
    <ToTop />
  </div>
</template>

<script>
import Layout from "./components/Layout";
import SiteAside from "./components/SiteAside"
import ToTop from "@/components/ToTop"
export default {
  components:{
    Layout,
    SiteAside,
    ToTop
  }
}
</script>

<style lang="less" scoped>
@import "~@/styles/mixin.less";
.app-container{
  .self-fill(fixed);
  // background:#008c8c;
  .aside{
    width:250px;
    height:100%;
  }
}
</style>