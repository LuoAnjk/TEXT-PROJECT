<template>
  <div id="app1">
    <p ref="para">some paragraph</p>
    <Demo ref="comp"></Demo>
    <button @click="handleClick">查看</button>
  </div>
</template>

<script>
/*
  $refs:{
    para:<p ref="para">some paragraph</p>,
    comp:子组件的实例
  }
*/ 
import Demo from "@/components/Demo"
export default {
  components:{
    Demo
  },
  methods:{
    handleClick(){
      console.log(this.$refs.comp.a,this.$refs.comp.b)
    }
  }
}
</script>

<style>

</style>