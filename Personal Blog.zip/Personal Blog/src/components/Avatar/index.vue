<template>
    <img class="avatar-container" :src="url" :style="{
      width:size + 'px',
      height:size + 'px'
    }" alt="">
</template>

<script>
  export default {
    props:{
      url:{
        type:String,
        required:true,
        default:"https://img2.baidu.com/it/u=4038653712,549556056&fm=253&fmt=auto&app=138&f=JPEG?w=488&h=284"
      },
      size:{
        type:Number
      }
    }
  }
</script>

<style lang="less" scoped>
  img{
    border-radius:50%;
    object-fit: cover;
    display:block;
  }
</style>

