<template>
  <div class="demo-container">
    <h1>ChildComp:a:{{ a }},b:{{ b }}</h1>
  </div>
</template>

<script>
export default {
  data(){
    return {
      a:1,
      b:2
    }
  },
  methods:{
    m1(){
      console.log("methods")
    }
  }
}
</script>

<style>

</style>