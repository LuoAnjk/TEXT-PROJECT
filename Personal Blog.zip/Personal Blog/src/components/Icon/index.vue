<template>
  <i class="icon-container iconfont" :class="fontClass"></i>
</template>

<script>
const classMap = {
  home: "icon-zhuye",
  success: "icon-icon_zhengqueshixin",
  error: "icon-error",
  close: "icon-icon_cuowu",
  warn: "icon-icon_jinggao",
  info: "icon-info",
  blog: "icon-bianjiwenzhang_huaban",
  code: "icon-icon_code",
  about: "icon-gengduo",
  weixin: "icon-weixin",
  mail: "icon-email",
  github: "icon-github",
  qq: "icon-qq",
  arrowUp: "icon-arrow-up",
  arrowDown: "icon-arrowdown",
  empty: "icon-clear1",
  chat: "icon-liuyan",
};
export default {
props: {
  type: {
    type: String,
    required: true,
  },
},
computed: {
  fontClass() {
    return classMap[this.type];
  },
},
};
</script>

<style lang="less" scoped>
  @import "//at.alicdn.com/t/c/font_2518201_h4y6g20wzlc.css";

</style>