<template>
  <ul class="contact-container">
    <li>
      <a href="">
        <div class="icon">
          <Icon type="github"></Icon>
        </div>
        <span>github地址</span>
      </a>
    </li>
    <li>
      <a href="mailto:13936619882@139.com">
        <div class="icon">
          <Icon type="mail"></Icon>
        </div>
        <span>13936619882@139.com</span>
      </a>
    </li>
    <li>
      <a href="">
        <div class="icon">
          <Icon type="qq"></Icon>
        </div>
        <span>3085745720</span>
      </a>
      <div class="pop">
        <img src="https://img0.baidu.com/it/u=3847369859,3712608412&fm=253&app=120&size=w931&n=0&f=JPEG&fmt=auto?sec=1741366800&t=5b3406bfa4a3cf88e38e98529096c92e" alt="">
      </div>
    </li>
    <li>
      <a href="">
        <div class="icon weixin">
          <Icon type="weixin"></Icon>
        </div>
        <span>Mr.chu</span>
      </a>
      <div class="pop">
        <img src="https://img0.baidu.com/it/u=3847369859,3712608412&fm=253&app=120&size=w931&n=0&f=JPEG&fmt=auto?sec=1741366800&t=5b3406bfa4a3cf88e38e98529096c92e" alt="">
      </div>
    </li>
  </ul>
</template>

<script>
import Icon from "@/components/Icon";
export default {
  components:{
    Icon
  }
}
</script>
<style lang="less" scoped>
@import "~@/styles/var.less";
.contact-container{
  width:100%;
  list-style:none;
  color:@gray;
  @itemHeight:30px;
  padding-left:15px;
  font-size:14px;
  li{
    height:@itemHeight;
    line-height:@itemHeight;
    margin:15px 0;
    position:relative;
    &:hover{
      .pop{
        transform: scaleY(1);
      }
    }
  }
  a{
    display: flex;
    align-items:center;
    cursor: pointer;
    .icon{
      width:36px;
      .icon-container{
        font-size:26px;
      }
      &.weixin{
       
        text-indent:-3px;
        .icon-container{
          font-size:32px;
        }
      }
    }
  }
  .pop{
    position:absolute;
    left:0;
    bottom:@itemHeight+5px;
    padding:10px 15px;
    background:#fff;
    border-radius: 5px;
    transform: scaleY(0);
    transform-origin: center bottom;
    transition: 0.3s;
    img{
      width:150px;
      height:150px;
      object-fit: cover;
    }
    &:after{
      content:'';
      position:absolute;
      width:8px;
      height:8px;
      background: #fff;
      left:50%;
      bottom:-4px;
      transform: translateX(-50%) rotate(45deg);
    }
  }
}
</style>