<template>
  <div class="site-aside-container">
    <template v-if="data">
      <Avatar :url="data.avatar" :size="150"></Avatar>
      <h1 class="title">{{data.siteTitle}}</h1>
    </template>
    <Menu></Menu>
    <Contact></Contact>
    <p class="footer" v-if="data">{{data.icp}}</p>
  </div>
</template>

<script>
import Avatar from "@/components/Avatar";
import Menu from "./Menu";
import Contact from "./Contact"
import {mapState} from "vuex"
export default {
  components:{
    Avatar,
    Menu,
    Contact
  },
  data(){
    return {
      url:"https://img0.baidu.com/it/u=2404252252,2360256337&fm=253&app=138&size=w931&n=0&f=JPEG&fmt=auto?sec=1741366800&t=dc91c2eefd9018285a074b465fc2f03d"
    }
  },
  computed:mapState("setting",["data"])
}
</script>

<style lang="less" scoped>
@import "~@/styles/var.less";
.site-aside-container{
  width:100%;
  height:100%;
  background:@dark;
  box-sizing:border-box;
  overflow-x: hidden;
  overflow-y: auto;
  padding-top:20px;
  .avatar-container{
    display:block;
    margin:0 auto;
  }
  .contact-container{
    margin-top:50px;
  }
  .title{
    font-size:1.2em;
    color:#fff;
    text-align:center;
    margin:20px 0;
  }
  .footer{
    text-align:center;
    font-size:12px;
    margin:20px 0;
  }
}
</style>