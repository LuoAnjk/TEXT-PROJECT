import Vue from 'vue'
import App from './App.vue'
// import App1 from "./App1.vue"
import "./styles/global.less";
import router from "./router"
import  showMessage  from './utils/showMessage';
import "./mock"
import vLoading from "@/directives/loading";
import vLazy from "@/directives/lazy"
import "./views/eventBus"
import store from "./store"
Vue.prototype.$showMessage = showMessage;
Vue.directive("loading",vLoading)
Vue.directive("lazy",vLazy)
const vm  = new Vue({
  router,
  store,
  render: h => h(App),
  // render: h => h(App1),
}).$mount('#app')

