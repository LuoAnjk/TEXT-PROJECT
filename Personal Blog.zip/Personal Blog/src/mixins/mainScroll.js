export default function (refvalue){
  return {
    mounted(){
      this.$bus.$on("setMainScroll",this.handleSetMainScroll);
      this.$refs[refvalue].addEventListener("scroll",this.handleMainScroll)
    },
    beforeDestroy() {
      this.$bus.$emit("mainScroll");
      this.$bus.$off("setMainScroll",this.handleSetMainScroll)
      this.$refs[refvalue].removeEventListener("scroll",this.handleMainScroll)
    },
    methods:{
      handleSetMainScroll(scrollTop){
        this.$refs[refvalue].scrollTop = scrollTop
      },
      handleMainScroll(){
        this.$bus.$emit("mainScroll",this.$refs[refvalue])
      }
    }
  }
}