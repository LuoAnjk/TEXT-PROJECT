import "./banner"
import "./blog"
import "./settings"
import "./about"
import "./project"
import Mock from "mockjs"
Mock.setup({
  timeout:`1000-2000`
})