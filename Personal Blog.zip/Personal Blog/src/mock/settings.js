import Mock from "mockjs"
Mock.mock("/api/setting","get",{
  code: 0,
	msg: "",
	data: {
    avatar: "https://img2.baidu.com/it/u=4038653712,549556056&fm=253&fmt=auto&app=138&f=JPEG?w=488&h=284", 
    siteTitle: "我的个人空间", 
    github: "https://xxx.com/git-git", 
    qq: "3263023350",
    qqQrCode:  "https://img2.baidu.com/it/u=1762118711,4071680279&fm=253&fmt=auto&app=138&f=JPEG?w=500&h=333", 
    weixin: "yh777bao", 
    weixinQrCode:      "https://img2.baidu.com/it/u=1762118711,4071680279&fm=253&fmt=auto&app=138&f=JPEG?w=500&h=333",
    mail: "13936619882@gmail.com", 
    icp: "黑ICP备17001719号", 
    githubName: "YunMa-Edu", 
    favicon: "https://img2.baidu.com/it/u=1762118711,4071680279&fm=253&fmt=auto&app=138&f=JPEG?w=500&h=333",
	}
})