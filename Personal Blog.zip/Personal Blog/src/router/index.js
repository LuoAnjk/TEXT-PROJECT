import Vue from "vue";
import VueRouter from "vue-router"
Vue.use(VueRouter)
import routes from "./routes"
import store from "@/store"
const router = new VueRouter({
  mode:"history",
  routes
})
router.afterEach((to,from)=>{
  if(to.meta.title){
    if(store.state.setting.data){
      document.title = to.meta.title + " - " + store.state.setting.data.siteTitle
    }else{
      document.title = to.meta.title
    }
  }
})
export default router