import Vuex from "vuex"
import Vue from "vue"
Vue.use(Vuex);
import banner from "./banner"
import setting from "./setting"
import about from "./about"
import project from "./project"
export default new Vuex.Store({
  modules:{
    banner,
    setting,
    about,
    project
  },
  strict:true
})