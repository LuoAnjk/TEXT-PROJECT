<template>
  <div class="blog-detail-container">
    <h1>{{ blog.title }}</h1>
    <div class="aside">
      <span>日期：{{ formateDate(blog.createDate) }}</span>
      <span>浏览：{{ blog.scanNumber }}</span>
      <a href="#data-form-container">评论：{{ blog.commentNumber }}</a>
      <RouterLink :to="{
        name:'CategoryBlog',
        params:{
          categoryId:blog.category.id
        }
      }">{{ blog.category.name }}</RouterLink>
    </div>
    <div v-html="blog.htmlContent" class="markdown-body"></div>
  </div>
</template>

<script>
import { formateDate } from '@/utils';
import "@/styles/markdown.css";
import "highlight.js/styles/github.css"
export default {
  props:{
    blog:{
      type:Object,
      required:true
    }
  },
  methods:{
    formateDate
  }
}
</script>
<style lang="less" scoped>
@import "~@/styles/var.less";
.aside{
  font-size: 12px;
  color:@gray;
  margin:20px 0px;
  span,a{
    margin-right:15px;
  }
}
.markdown-body{
  margin:2em 0px;
}
</style>