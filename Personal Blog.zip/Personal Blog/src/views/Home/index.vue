<template>
  <div 
    class="home-container" 
    ref="container" 
    @wheel="handleWheel" 
    v-loading="loading"
  >
    <ul 
      class="carouse-container" 
      :style="{marginTop}"
      @transitionend="handleTransitionEnd"  
    >
      <li v-for="item in data" :key="item.id">
        <CarouseItem :carousel="item"></CarouseItem>
      </li>
    </ul>
    <div class="icon icon-up" v-show="index>=1" @click="switchTo(index-1)">
      <Icon type="arrowUp"></Icon>
    </div>
    <div class="icon icon-down" v-show="index<data.length-1" @click="switchTo(index+1)">
      <Icon type="arrowDown"></Icon>
    </div>
    <ul class="indicator">
      <li v-for="(item,i) in data" :key="item.id" :class="{active:i === index}" @click="switchTo(i)"></li>
    </ul>
  </div>
</template>

<script>
// import {getBanners} from "@/api/banner"
import CarouseItem from "./CarouseItem.vue";
import Icon from "@/components/Icon"
// import fetchData from "@/mixins/fetchData";
import {mapState} from "vuex"
export default {
  // mixins:[fetchData([])],
  components:{
    CarouseItem,
    Icon
  },
  data(){
    return {
      // isLoading:true,
      // banners:[],
      index:0, //表示当前为第几张图片的索引
      containerHeight:0,
      switching:false,//是否正在翻动中
    }
  },
  methods:{
    switchTo(i){
      this.index = i
    },
    handleWheel(e){
      if(this.switching){
        return 
      }    
      if(e.deltaY<-5 && this.index >0){
        this.switching = true
        this.index--
      }else if(e.deltaY > 5 && this.index<this.data.length-1){
        this.switching =true
        this.index++
      }
    },
    handleTransitionEnd(){
      this.switching = false
    },
    handleResize(){
      this.containerHeight = this.$refs.container.clientHeight;
    },
    // async fetchData(){
    //   return await getBanners()
    // }
  },
  // async created(){
  //   this.banners = await getBanners();
  //   this.isLoading = false
  // },
  created(){
    this.$store.dispatch("banner/fetchBanner")
  },
  mounted(){
    this.containerHeight = this.$refs.container.clientHeight;
    window.addEventListener("resize",this.handleResize)
  },
  destroyed(){
    window.removeEventListener("resize",this.handleResize)
  },
  computed:{
    marginTop(){
      return -this.index * this.containerHeight + "px";
    },
    ...mapState("banner",["loading","data"])
  },
 
 
}
</script>

<style lang="less" scoped>
@import "~@/styles/mixin.less";
@import "~@/styles/var.less";
.home-container{
  width:100%;
  height:100%;
  position:relative;
  overflow: hidden;
  ul{
    margin:0;
    list-style: none;
    padding:0;
  }
  .carouse-container{
    width: 100%;
    height:100%;
    transition: 500ms;
    li{
      width:100%;
      height:100%;
      // background:lightcyan;
    }
  }
  .icon{
    .self-center();
    @gap:15px;
    color:@gray;
    cursor: pointer;
    transform: translateX(-50%);
    &.icon-up{
      top:@gap;
      animation: jump-up 2s infinite;
    }
    &.icon-down{
      top:auto;
      bottom:@gap;
      animation: jump-down 2s infinite;
    }
    .icon-container{
      font-size:30px;
    }
  }
  @jump:5px;
  @keyframes jump-up {
    0%{
      transform: translate(-50%,@jump);
    }
    50%{
      transform: translate(-50%,-@jump);
    }
    100%{
      transform: translate(-50%,@jump);
    }
  }
  @keyframes jump-down {
    0%{
      transform: translate(-50%,-@jump);
    }
    50%{
      transform: translate(-50%,@jump);
    }
    100%{
      transform: translate(-50%,-@jump);
    }
  }
  .indicator{
    .self-center();
    transform: translateY(-50%);
    left:auto;
    right:20px;
    li{
      width:8px;
      height:8px;
      border-radius: 50%;
      background:@words;
      cursor:pointer;
      margin-bottom:10px;
      border:1px solid #fff;
      box-sizing:border-box;
      &.active{
        background:#fff;
      }
    }
  }
}
</style>